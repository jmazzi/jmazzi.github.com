<?php
    /* $Id: preferences.php,v 1.3 2002/11/01 02:33:19 root Exp $ */
    require('config.php');
    clientpageheader("User Preferences");
     
    if (!$action || $action == '') {
        $action = "view";
    }
    if ($action == "view") {
        $sql = "select name from styles where styleid='$auth_row[style]'";
        $result = mysql_query($sql);
        $current_style = @mysql_result($result, 0);
        $sql = "select styleid, name from styles order by name";
        $result = mysql_query($sql);
        $num_results = mysql_num_rows($result);
        eval("output(\"".template("clientpreferencesviewheader")."\");");
         
        while ($info = mysql_fetch_array($result)) {
            $styleid = ($info['styleid']);
            $name = ($info['name']);
            eval("output(\"".template("clientpreferencesviewbody")."\");");
        }
    }
     
    if ($action == "set") {
        mysql_query("update clientusers set style='$styleid' where cid='$auth_row[cid]'");
        eval("output(\"".template("clientpreferencesupdated")."\");");
    }
     
     
