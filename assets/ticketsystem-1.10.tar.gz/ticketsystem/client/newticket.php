<?php
    /* $Id: newticket.php,v 1.5 2002/11/01 02:33:19 root Exp $ */
    require "config.php";
     
    clientpageheader("Submit Trouble Ticket");
     
    if (!$name || !$email || !$subject || !$question) {
        if ($action == "send") eval("\$error = \"".template("submitticketformerror")."\";");
            if ($priority == "High") $priority1 = "selected";
        if ($priority == "Medium") $priority2 = "selected";
        if ($priority == "Low") $priority3 = "selected";
        $sql = "select name, emailaddress from clientusers where cid='$auth_row[cid]'";
        $result = mysql_query($sql);
        $customerinfo = mysql_fetch_array($result);
        $clientname = $customerinfo[name];
        $clientemail = $customerinfo[emailaddress];
        eval("output(\"".template("clientsubmitticketform")."\");");
    }
     
    else
        {
        $question = htmlspecialchars($question);
        $name = htmlspecialchars($name);
        $subject = htmlspecialchars($subject);
        $domain = htmlspecialchars($domain);
        $email = htmlspecialchars($email);
         
        $sql = "SELECT count(*) as count from tickets where name='$name' and email='$email' and subject='$subject' and priority_level='$priority' and domain='$domain' and request='$question'";
         
        $entries = mysql_query($sql);
        $info = mysql_fetch_array($entries);
         
        if ($info[count] > 0) {
            eval("output(\"".template("submitticketerror")."\");");
        }
         
        else
             
        {
            if ($domain == "http://") $domain = "";
            $sql = "insert into tickets set name='$name', email='$email', subject='$subject', priority_level='$priority', domain='$domain', request='$question', requestdate=now(), requesttime=now(), ipaddress='$REMOTE_ADDR', cid='$auth_row[cid]'";
            mysql_query($sql);
             
            $sql = "select count(tid) from tickets limit 1";
            $result = mysql_query($sql);
            $ticketnumber = mysql_result($result, 0);
            eval("output(\"".template("submitticketsuccess")."\");");
             
            $body = "$name submited this question:
                 
                $question
                 
                subject: $subject
                domain: $domain
                email address: $email
                 
                http://linuxgroup.net/ticketsystem/admin/ticketview.php?tid=$ticketnumber
                ";
             
            $body = "
                Your ticket was received and will be followed up on shortly. Your ticket number is $ticketnumber. Thank you for patience.
                 
                The LinuxGroup Team";
             
            $emaildate = date("F j, Y, g:i a");
            mail("$email", "Your ticket $ticketnumber was received  on $emaildate", $body , "From: $supportname<$supportemail>");
        }
    }
     
    clientpagefooter();
?>
