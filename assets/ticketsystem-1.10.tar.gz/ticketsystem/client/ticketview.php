<?php
    /* $Id: ticketview.php,v 1.5 2002/11/01 02:33:19 root Exp $ */
    require 'config.php';
     
    if (!$tid) header("location: ticketlist.php?by=tid");
     
    clientpageheader("Trouble Ticket #$tid");
    $signature = $auth_row[signature];
     
    $sql = "select tid, name, email, domain, subject, status, priority_level, request, requestdate, requesttime from tickets where tid = '$tid' and cid='$auth_row[cid]'";
    $result = mysql_query($sql);
     
    while ($info = mysql_fetch_array($result)) {
        $requesttime = $info[requesttime];
        $requestdate = $info[requestdate];
        $name = $info[name];
        $email = $info[email];
        $subject = $info[subject];
        $priority_level = $info[priority_level];
        $domain = $info[domain];
        $status = $info[status];
        eval("output(\"".template("clientticketviewheader")."\");");
         
        $sql = "select tid, staffuser, response, replydate, replytime from responses where tid = '$tid' and cid='$auth_row[cid]'";
        $result = mysql_query($sql);
        $question = nl2br($info[request]);
        eval("output(\"".template("clientticketviewquestion")."\");");
         
        while ($info = mysql_fetch_array($result)) {
            $responsetext = nl2br($info[response]);
            $replytime = $info[replytime];
            $replydate = $info[replydate];
            $staffuser = $info[staffuser];
            eval("output(\"".template("clientticketviewwrote")."\");");
        }
        eval("output(\"".template("clientticketviewreplyform")."\");");
         
        if ($status == "WOC") {
            eval("output(\"".template("clientticketviewstatuswoc")."\");");
        }
         
        if ($status == "Open") {
            eval("output(\"".template("clientticketviewstatusopen")."\");");
        }
         
        else if ($status == "Closed") {
            eval("output(\"".template("clientticketviewstatusclosed")."\");");
        }
         
    }
     
    clientpagefooter();
     
?>
