<?php
    /* $Id: index.php,v 1.5 2002/11/01 02:33:19 root Exp $ */
    require "config.php";
     
    clientpageheader("Trouble Ticket Administration");
    eval("output(\"".template("clientindex")."\");");
     
    clientpagefooter();
     
?>
