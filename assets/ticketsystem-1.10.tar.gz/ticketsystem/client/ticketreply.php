<?php
    /* $Id: ticketreply.php,v 1.5 2002/11/01 02:33:19 root Exp $ */
    require "config.php";
     
    pageheader("Reply to Trouble Ticket");
     
    if ($action == "send") {
        $response = htmlspecialchars($response);
         
        $sql = "insert into responses (tid, cid, staffuser, response, replydate, replytime) values ('$tid', '$auth_row[cid]', '$PHP_AUTH_USER', '$response', now(), now())";
        mysql_query($sql);
        mysql_query("update tickets set status='Open' where tid='$tid' and cid='$auth_row[cid]");
        $response = "$response
             
            Click this link http://linuxgroup.net/ticketsystem/client/ticketview.php?tid=$tid to view your ticket.
            ";
         
         
        $sql = "select emailaddress from clientusers where cid='$auth_row[cid]'";
        $result = mysql_query($sql);
        $emailaddress = mysql_result($result, 0);
        $emaildate = date("F j, Y, g:i a");
        mail("$emailaddress", "Response for Ticket $tid on $emaildate", $response , "From: $supportname<$supportemail>");
        eval("output(\"".template("clientticketreplysent")."\");");
    }
     
    pagefooter();
     
?>
