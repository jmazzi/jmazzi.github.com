<?php
    /* $Id: ticket.php,v 1.5 2002/11/01 02:33:19 root Exp $ */
    require('config.php');
     
    clientpageheader("Choose an account");
     
    $sql = "select domain from accounts where cid='$auth_row[cid]'";
    $result = mysql_query($sql);
     
    eval("output(\"".template("clientticketaccountsheader")."\");");
    while ($accountinfo = mysql_fetch_array($result)) {
        echo "<option value='$accountinfo[domain]'>$accountinfo[domain]</option>";
    }
    eval("output(\"".template("clientticketaccountsfooter")."\");");
     
