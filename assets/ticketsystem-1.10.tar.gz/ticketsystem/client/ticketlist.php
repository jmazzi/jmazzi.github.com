<?php
    /* $Id: ticketlist.php,v 1.6 2002/11/01 02:33:19 root Exp $ */
    require "config.php";
    clientpageheader("Trouble Tickets List");
     
    if (!$status || $status == '') {
        $status = "Open";
    }
     
    if (!$order || $order == '') {
        $order = "desc";
    }
     
    if (!$by || $by == '') {
        $by = "tid";
    }
     
     
    $sql = "select tid, domain, subject, priority_level, status from tickets where status !='Closed' and cid='$auth_row[cid]' order by $by $order";
    $result = mysql_query($sql);
    $num_results = mysql_num_rows($result);
     
    eval("output(\"".template("clientticketlistheader")."\");");
     
    while ($info = mysql_fetch_array($result)) {
        $tid = ($info['tid']);
        $domain = ($info['domain']);
        $subject = ($info['subject']);
        $priority_level = ($info['priority_level']);
        eval("output(\"".template("clientticketlistbody")."\");");
    }
     
    eval("output(\"".template("clientticketlistfooter")."\");");
    clientpagefooter();
     
?>
