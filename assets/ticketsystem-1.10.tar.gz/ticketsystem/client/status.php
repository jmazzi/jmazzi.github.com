<?php
    /* $Id: status.php,v 1.5 2002/11/01 02:33:19 root Exp $ */
    require('config.php');
     
    clientpageheader("Change Ticket Status for TID #$tid");
    eval("output(\"".template("clientstatusheader")."\");");
     
    $sql = "update tickets set status = '$status' where tid ='$tid' and cid='$auth_row[cid]'";
    $result = mysql_query($sql);
     
    if ($status == 'Closed') {
        $result;
        eval("output(\"".template("clientstatuschanged")."\");");
    }
     
    else if ($status == 'Open') {
        $result;
        eval("output(\"".template("clientstatuschanged")."\");");
    }
     
    else
        {
        eval("output(\"".template("clientstatusnotchanged")."\");");
    }
     
    eval("output(\"".template("clientstatusfooter")."\");");
    clientpagefooter();
     
?>
			
