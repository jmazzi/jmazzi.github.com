--$Id: ticketsystem.sql,v 1.7 2002/07/09 02:06:57 root Exp $--
-- MySQL dump 8.22
--
-- Host: localhost    Database: linux_tickets
---------------------------------------------------------
-- Server version	3.23.51

--
-- Table structure for table 'accounts'
--

CREATE TABLE accounts (
  aid bigint(20) NOT NULL auto_increment,
  cid varchar(20) NOT NULL default '',
  domain varchar(100) NOT NULL default '',
  active enum('Y','N') NOT NULL default 'Y',
  PRIMARY KEY  (aid)
) TYPE=MyISAM;

--
-- Dumping data for table 'accounts'
--



--
-- Table structure for table 'banned'
--

CREATE TABLE banned (
  id int(11) NOT NULL auto_increment,
  ipaddress varchar(15) NOT NULL default '',
  comment tinytext NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY ipaddress (ipaddress),
  KEY ipaddress_2 (ipaddress)
) TYPE=MyISAM;

--
-- Dumping data for table 'banned'
--



--
-- Table structure for table 'clientusers'
--

CREATE TABLE clientusers (
  cid bigint(20) NOT NULL auto_increment,
  name varchar(60) NOT NULL default '',
  username varchar(20) NOT NULL default '',
  password varchar(32) NOT NULL default '',
  emailaddress varchar(100) NOT NULL default '',
  active enum('Y','N') NOT NULL default 'Y',
  style int(11) NOT NULL default '0',
  PRIMARY KEY  (cid)
) TYPE=MyISAM;

--
-- Dumping data for table 'clientusers'
--


INSERT INTO clientusers VALUES (1,'user','user','ee11cbb19052e40b07aac0ca060c23ee','','Y',1);

--
-- Table structure for table 'config'
--

CREATE TABLE config (
  style char(3) NOT NULL default '',
  templateset varchar(50) NOT NULL default ''
) TYPE=MyISAM;

--
-- Dumping data for table 'config'
--


INSERT INTO config VALUES ('1','default');

--
-- Table structure for table 'qw_response'
--

CREATE TABLE qw_response (
  qid mediumint(5) NOT NULL auto_increment,
  name varchar(20) NOT NULL default '',
  response text NOT NULL,
  PRIMARY KEY  (qid)
) TYPE=MyISAM;

--
-- Dumping data for table 'qw_response'
--



--
-- Table structure for table 'responses'
--

CREATE TABLE responses (
  rid int(11) NOT NULL auto_increment,
  tid varchar(10) NOT NULL default '',
  cid varchar(32) default NULL,
  staffuser varchar(25) NOT NULL default '',
  response text NOT NULL,
  replydate date default NULL,
  replytime time NOT NULL default '00:00:00',
  PRIMARY KEY  (rid)
) TYPE=MyISAM;

--
-- Dumping data for table 'responses'
--



--
-- Table structure for table 'staffnotes'
--

CREATE TABLE staffnotes (
  nid int(11) NOT NULL auto_increment,
  tid varchar(10) NOT NULL default '',
  staffuser varchar(25) NOT NULL default '',
  notes text NOT NULL,
  notedate date NOT NULL default '0000-00-00',
  notetime time default NULL,
  PRIMARY KEY  (nid)
) TYPE=MyISAM;

--
-- Dumping data for table 'staffnotes'
--



--
-- Table structure for table 'styles'
--

CREATE TABLE styles (
  styleid tinyint(4) NOT NULL auto_increment,
  groupname varchar(20) NOT NULL default 'default',
  name varchar(20) NOT NULL default '',
  code text NOT NULL,
  PRIMARY KEY  (styleid)
) TYPE=MyISAM;

--
-- Dumping data for table 'styles'
--


INSERT INTO styles VALUES (1,'default','Standard','                        a        {color: #000000; text-decoration: underline}\r\na:visited {color: #000000; text-decoration: underline}\r\na:hover  {color: #0E3666; text-decoration: none}\r\na:active {color: #0E3666; text-decoration: none}\r\n\r\n.mlink   {color:#000000; font-family:Tahoma; font-size: 13px; line-height:140%}\r\n.mlink a:link    {color:#000000; text-decoration: none}\r\n.mlink a:visited {color:#000000; text-decoration: none}\r\n.mlink a:hover   {color:#000000; text-decoration: none}\r\n\r\n\r\nBODY { SCROLLBAR-BASE-COLOR: #0E6999; SCROLLBAR-ARROW-COLOR: #EEEEEE; BACKGROUND-COLOR: #DFDFDF; FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif;}\r\nSELECT { FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR: #CF\r\nCFCF }\r\nINPUT { FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR: #CFC\r\nFCF }\r\nTEXTAREA { FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR: #\r\nCFCFCF }\r\nTD { FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; }\r\n\r\n#title { BACKGROUND-COLOR: #0E6999; }\r\n#content { BACKGROUND-COLOR: #DEDEDE; }\r\n#tableborder { BACKGROUND-COLOR: #000000; }');
INSERT INTO styles VALUES (2,'default','Orange Blue','                      BODY { SCROLLBAR-BASE-COLOR: #E0E4E8; SCROLLBAR-ARROW-COLOR: #000000; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; }\r\nSELECT { FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 11px; COLOR: #000000; BACKGROUND-COLOR:\r\n#CFCFCF }\r\nTEXTAREA, .input { FONT-SIZE: 11px; FONT-WEIGHT:bold; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; COLOR:\r\n #000000; BACKGROUND-COLOR: #FFFFFF; border-style:  solid; border-left-width: 1px; border-top-width: 1px; border\r\n-right-width: 1px; border-bottom-width: 1px; border-color: #000000;}\r\nTD { FONT-FAMILY: Verdana,Arial,Helvetica,sans-serif; }\r\n\r\n\r\n\r\nA:link,  A:visited,  A:active { COLOR: #000000; TEXT-DECORATION: none; }\r\nA:hover { COLOR: #F99500; TEXT-DECORATION: underline; }\r\n\r\n#title { BACKGROUND-COLOR: #006699; }\r\n#content { BACKGROUND-COLOR: #BAD0E0; }\r\n#tableborder { BACKGROUND-COLOR: #FFFFFF; }\r\n');
INSERT INTO styles VALUES (3,'default','OpenBB','BODY {FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif;}\r\nSELECT 		{BACKGROUND-COLOR: #DEDEDE; COLOR: #000000; FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif; FONT-SIZE: 10px}\r\nINPUT 		{BACKGROUND-COLOR: #DEDEDE; COLOR: #000000; FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif; FONT-SIZE: 10px}\r\nTEXTAREA	{BACKGROUND-COLOR: #DEDEDE; COLOR: #000000; FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif; FONT-SIZE: 10px}\r\nOPTION 		{BACKGROUND-COLOR: #DEDEDE; COLOR: #000000; FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif; FONT-SIZE: 10px}\r\nFORM 		{FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif; FONT-SIZE: 10px}\r\nTD {FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif;}\r\na:link {  color: #000000; text-decoration: none}\r\na:visited {  color: #000000; text-decoration: none}\r\na:active {  color: #000000; text-decoration: none}\r\na:hover {  color: #000000; text-decoration: underline}\r\n\r\n#title { BACKGROUND-COLOR: #0E6999; }\r\n#content { BACKGROUND-COLOR: #DEDEDE; }\r\n#tableborder { BACKGROUND-COLOR: #000000; }');
INSERT INTO styles VALUES (4,'default','Fizz','a:link {  color: #000000; text-decoration: none}\r\na:visited {  color: #000000; text-decoration: none}\r\na:active {  color: #FF3300; text-decoration: none}\r\na:hover {  color: #FF3300; text-decoration: underline}\r\n\r\n\r\nINPUT, SELECT, TEXTAREA		{\r\n	BACKGROUND-COLOR: #BBC3C9;\r\n	COLOR: #000000;\r\n	FONT-FAMILY: Verdana,Geneva,Arial,Helvetica,sans-serif;\r\n	FONT-SIZE: 12px;\r\n	BORDER-LEFT: #000000 solid 1px;\r\n	BORDER-RIGHT: #000000 solid 1px;\r\n	BORDER-TOP: #000000 solid 1px;\r\n	BORDER-BOTTOM: #000000 solid 1px;\r\n\r\n#title { BACKGROUND-COLOR: #748c9c; }\r\n#content { BACKGROUND-COLOR: #BBC3C9; }\r\n#tableborder { BACKGROUND-COLOR: #006385; }\r\n');
INSERT INTO styles VALUES (5,'default','Some Style','BODY {COLOR: white;BACKGROUND: #3060ff;FONT-FAMILY: verdana; FONT-SIZE: 10pt}\r\nTD   {COLOR: white;FONT-FAMILY: verdana; FONT-SIZE: 10pt}\r\n\r\n.col1  {COLOR: #ffdd00}\r\n\r\nINPUT.inp {BORDER: 1px solid #000000;BACKGROUND: #ffffff}\r\n\r\nINPUT.sub {margin-top: 2px;FONT-WEIGHT: bold;BORDER: 1px solid #000000;BACKGROUND: #ffdd00}\r\n\r\nA {COLOR: #ffffff; TEXT-DECORATION: none}\r\nA:visited {COLOR: #ffffff; TEXT-DECORATION: none}\r\nA:hover {COLOR: #ffffff; TEXT-DECORATION: underline}\r\n\r\n#title {COLOR:#000000 ;FONT-WEIGHT: bold;BACKGROUND: #ADC0FF}\r\n#content {BACKGROUND: #7394FF;FONT-WEIGHT: bold}\r\n#tableboarder {BACKGROUND: #FFdd00;COLOR: black;FONT-WEIGHT: bold}\r\n\r\n');

--
-- Table structure for table 'templates'
--

CREATE TABLE templates (
  templateid int(11) NOT NULL auto_increment,
  groupname varchar(50) NOT NULL default 'default',
  name varchar(50) NOT NULL default '',
  code text NOT NULL,
  PRIMARY KEY  (templateid)
) TYPE=MyISAM;

--
-- Dumping data for table 'templates'
--


INSERT INTO templates VALUES (1,'default','adminindex','<a href=\'ticketlist.php\'>Open Tickets</a><br>\r\n<br>\r\n<a href=\'ticketlist.php?status=WOC\'>WOC Tickets</a><br>\r\n<br>\r\n<a href=\'ticketlist.php?status=Closed\'>Closed Tickets</a> <br>\r\n<br>\r\n<a href=\'stylemanager.php\'>Style Manager</a> <br>\r\n<br>\r\n<a href=\'qrmanager.php\'>Quick Response Manager</a> <br>\r\n<br>\r\n<br>\r\n<a href=\'../public/ticket.php\'>Submit New Ticket</a><br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\nUser ID :<b> $auth_row[id]</b> <br>\r\nUser name :<b> $auth_row[name]</b> <br>\r\n<br>\r\n');
INSERT INTO templates VALUES (2,'default','submitticketform','<form method=POST action=\'ticket.php\'>\r\n<table width=\'600\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n	<tr>\r\n		<td colspan=2 id=\'title\'><b>Submit Trouble Ticket</b> <font color=\'#FF0000\'>$error</font></td>\r\n	</tr>\r\n	<tr>\r\n		<td align=\'right\' id=\'content\'>Name:</td>\r\n		<td id=\'content\'><input type=text name=\'name\' value=\'$name\' size=30></td>\r\n	</tr>\r\n	<tr>\r\n		<td align=\'right\' id=\'content\'>Email:</td>\r\n		<td id=\'content\'><input type=text name=\'email\' value=\'$email\' size=30></td>\r\n	</tr>\r\n	<tr>\r\n		<td align=\'right\' id=\'content\'>Subject:</td>\r\n		<td id=\'content\'><input type=text name=\'subject\' value=\'$subject\' size=30></td>\r\n	</tr>\r\n	<tr>\r\n		<td align=\'right\' id=\'content\'>Priority:</td>\r\n		<td id=\'content\'><select name=\'priority\'>\r\n                                <option value=\'Low\' $priority3>Low</option>\r\n		<option value=\'Medium\' $priority2>Medium</option>\r\n		<option value=\'High\' $priority1>High</option></select></td>\r\n			</tr>\r\n	<tr>\r\n		<td align=\'right\' id=\'content\'>Domain:</td>\r\n		<td id=\'content\'><input type=text name=\'domain\' value=\'$domain\' size=30> Please do not include \'http://\'\r\n</td>\r\n	</tr>\r\n	<tr>\r\n		<td align=\'right\' id=\'content\'>Question:</td>\r\n		<td id=\'content\'><textarea name=\'question\' rows=10 cols=77 wrap=hard>$question</textarea></td>\r\n	</tr>\r\n	<tr>\r\n		<td id=\'title\'></td>\r\n		<td id=\'title\'><input type=hidden name=mode value=send><input type=submit value=\'Send\'> <input type=reset value=\'Reset\'></td>\r\n	</tr>\r\n</table>\r\n</form>');
INSERT INTO templates VALUES (3,'default','styleviewheader','<p>\r\n<center>\r\nAvailable Styles: $num_results\r\n</center>\r\n</p>\r\n\r\n<table width=\'50%\' cellpadding=4 cellspacing=1 border=0 id=tableborder align=center>\r\n\r\n<tr>\r\n<td id=title><div align=center>Styleid</div></td>\r\n<td id=title><div align=center>Name</div></td>\r\n<td id=title><div align=center>Set Style</div></td>\r\n<td id=title><div align=center>Delete</div></td>\r\n</tr>');
INSERT INTO templates VALUES (4,'default','adminheader','<html>\r\n<title>Ticket System - $pagetitle</title>\r\n<head>\r\n<STYLE TYPE=\'TEXT/CSS\'>\r\n$css\r\n</STYLE>\r\n</head><center>\r\n<body>\r\n<table width=\'91%\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n  <tr> \r\n    <td colspan=4 id=\'title\'>Trouble Tickets</td>\r\n    <td colspan=4 id=\'title\'>Edit...</td>\r\n  </tr>\r\n  <tr> \r\n    <td width=\'13%\' id=\'content\'><a href=\'../public/ticket.php\'>Submit New</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'ticketlist.php\'>View Opened</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'ticketlist.php?status=WOC\'>View WOC</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'ticketlist.php?status=Closed\'>View Closed</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'stylemanager.php\'>Styles</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'qrmanager.php\'>Quick Responses</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'templatemanager.php\'>Templates</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'usermanager.php\'>Admin Users</a></td>\r\n  </tr>\r\n</table>\r\n<br>\r\n<br>\r\n');
INSERT INTO templates VALUES (5,'default','adminfooter','<br>\r\n<br>\r\n<font size=1>Powered by: TicketOne Alpha 1.4<br>\r\nCopyright � 2002 LinuxGroup.net</font> \r\n</body></center>\r\n</html>\r\n');
INSERT INTO templates VALUES (6,'default','submitticketerror','Your ticket has already been sent, please do not submit it again.');
INSERT INTO templates VALUES (7,'default','submitticketsuccess','Ticket has been sent! Your ticket number is <b>$ticketnumber</b>.');
INSERT INTO templates VALUES (8,'default','submitticketformerror','Please fill out all the fields!');
INSERT INTO templates VALUES (9,'default','styleviewbody','<tr>\r\n<td id=content><div align=center><a href=\'$PHP_SELF?action=edit&styleid=$styleid\'>$styleid</a></div></td>\r\n<td id=content><div align=center>$name</div></td>\r\n<td id=content><div align=center><a href=\'$PHP_SELF?action=set&styleid=$styleid&groupname=$groupnameoutput\'>Set</a></div></td>\r\n<td id=content><div align=center><a href=\'$PHP_SELF?action=confirm&styleid=$styleid&name=$name\'>Delete</a></div></td>\r\n</tr>');
INSERT INTO templates VALUES (10,'default','styleviewfooter','</table>\r\n<br><br>\r\n<a href=\'$PHP_SELF?action=addform\'>Add New</a>\r\n<br><br>\r\nThe current style is <b>$style</b>\r\n<br><br>\r\n<a href=\'index.php\'>Main Page</a>');
INSERT INTO templates VALUES (11,'default','styleedit','<form method=POST action=\'$PHP_SELF\'>\r\n<input type=hidden name=action value=send>\r\n<input type=hidden name=styleid value=$styleid>\r\nStyle Name\r\n<br>\r\n<input type=text name=\'name\' rows=0 cols=0 value=\'$name\'></textarea><br>\r\nGroup Name\r\n<br>\r\n<input type=text name=\'groupname\' rows=0 cols=0 value=\'$groupname\'></textarea><br>\r\n<textarea name=\'code\' rows=30 cols=70>$code</textarea><br>\r\n<input type=submit value=\'Send\'> <input type=reset value=\'Reset\'>\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back to Style Manager</a>');
INSERT INTO templates VALUES (12,'default','templateupdated','<b>$templatename</b> has been updated in the <b>$groupname</b> group\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back to Template Manager</a>');
INSERT INTO templates VALUES (13,'default','styleset','The Style has been set to style #: <b>$styleid</b>\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back</a>');
INSERT INTO templates VALUES (14,'default','styleaddform','<form method=POST action=\'$PHP_SELF\'>\r\n<input type=hidden name=action value=add>\r\nName of Template set to use<br>\r\n<input type=text name=\'groupname\' rows=0 cols=0></textarea><br>\r\nName of Style<br>\r\n<input type=text name=\'name\' rows=0 cols=0></textarea><br>\r\n<textarea name=\'code\' rows=30 cols=70></textarea><br>\r\n<input type=submit value=\'Send\'> <input type=reset value=\'Reset\'>');
INSERT INTO templates VALUES (15,'default','styleadded','Sucessfully added <b>$name</b> as a style\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back</a>');
INSERT INTO templates VALUES (16,'default','styleconfirmdelete','Delete the style <b>$name</b> ?\r\n<br><br>\r\n<a href=\'$PHP_SELF?action=delete&styleid=$styleid\'>Yes</a>\r\n<br>\r\n<a href=\'$PHP_SELF\'>no</a>');
INSERT INTO templates VALUES (17,'default','styledeleted','Sucessfully deleted <b>$styleid</b>\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back</a>');
INSERT INTO templates VALUES (18,'default','qrviewheader','<p>\r\n<center>\r\nAvailable Quick Responses: $num_results\r\n</center>\r\n</p>\r\n<table width=\\\"50%\\\" cellpadding=4 cellspacing=1 border=0 id=tableborder align=center>\r\n<tr>\r\n<td id=title><div align=center>Qid</div></td>\r\n<td id=\'title\'><div align=center>Name</div></td>\r\n<td id=title><div align=center>Delete</div></td>\r\n</tr>');
INSERT INTO templates VALUES (19,'default','qrviewbody','<tr>\r\n<td id=content><div align=center>\r\n<a href=\'$PHP_SELF?action=edit&qid=$qid\'>$qid</a></div></td>\r\n<td id=content><div align=center>$name</div></td>\r\n<td id=content><div align=center><a href=\'$PHP_SELF?action=confirm&qid=$qid&name=$name\'>Delete</a></div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (20,'default','qrviewfooter','</table>\r\n<br><br>\r\n<a href=\'$PHP_SELF?action=addform\'>Add New</a>\r\n<br><br>\r\n<a href=\'index.php\'>Main Page</a>');
INSERT INTO templates VALUES (21,'default','qredit','<form method=POST action=\'$PHP_SELF\'>\r\n<input type=hidden name=action value=send>\r\n<input type=hidden name=qid value=$qid>\r\n<input type=text name=\'name\' rows=0 cols=0 value=\'$name\'></textarea><br>\r\n<textarea name=\'response\' rows=30 cols=70>$response</textarea><br>\r\n<input type=submit value=\'Send\'> <input type=reset value=\'Reset\'>\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back to Quick Response Manager</a>\r\n');
INSERT INTO templates VALUES (22,'default','qrsend','Qid #: <b>$qid</b> has been updated\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back to Quick Response Manager</a>');
INSERT INTO templates VALUES (23,'default','qraddform','<form method=POST action=\'$PHP_SELF\'>\r\n<input type=hidden name=action value=add>\r\nName of Quick Response<br>\r\n<input type=text name=\'name\' rows=0 cols=0></textarea><br>\r\n<textarea name=\'response\' rows=30 cols=70></textarea><br>\r\n<input type=submit value=\'Send\'> <input type=reset value=\'Reset\'>');
INSERT INTO templates VALUES (24,'default','qradd','Sucessfully added <b>$name</b> as a Quick Response\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back</a>');
INSERT INTO templates VALUES (25,'default','qrconfirmdelete','Delete the Quick Response <b>$name</b> ?\r\n<br><br>\r\n<a href=\'$PHP_SELF?action=delete&qid=$qid&name=$name\'>Yes</a>\r\n<br>\r\n<a href=\'$PHP_SELF\'>no</a>');
INSERT INTO templates VALUES (26,'default','qrdeleted','Sucessfully deleted<b> $name</b>\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back</a>');
INSERT INTO templates VALUES (27,'default','adminuseraddform','<form method=POST action=\'$PHP_SELF?action=add\'> \r\n<input type=hidden name=action value=add>\r\nUsername<br>\r\n<input type=text name=\'name\' rows=0 cols=0></textarea>\r\n<br>\r\nPassword<br>\r\n<input type=password name=\'password\' rows=0 cols=0></textarea>\r\n<br>\r\nCan use the template manager<br>\r\n<select name=\'cantemplate\'>\r\n  <option value=\'Y\'>Yes</option>\r\n  <option value=\'N\'>No</option>\r\n</select>\r\n<br>\r\nCan user the admin user manager<br>\r\n<select name=\'canuseradmin\'>\r\n  <option value=\'Y\'>Yes</option>\r\n  <option value=\'N\'>No</option>\r\n</select>\r\n<br>\r\n<input type=submit value=\'Send\'>\r\n<input type=reset value=\'Reset\'>\r\n');
INSERT INTO templates VALUES (28,'default','adminuserviewbody','<tr> \r\n  <td id=content><div align=center>$id</div></td>\r\n  <td id=content><div align=center><a href=\'$PHP_SELF?action=permissions&name=$name&id=$id\'>$name</a></div></td>\r\n  <td id=content><div align=center><a href=\'$PHP_SELF?action=changepassform&id=$id&name=$name\'>$password</a></div></td>\r\n  <td id=content><div align=center>$cantemplate</div></td>\r\n  <td id=content><div align=center>$canuseradmin</div></td>\r\n  <td id=content><div align=center><a href=\'$PHP_SELF?action=confirmdelete&id=$id&name=$name\'>Delete</a></div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (29,'default','adminuserviewheader','<p>\r\n<center>\r\nAdmin Users: $view_num_results\r\n</center>\r\n</p>\r\n\r\n<table width=\'65%\' cellpadding=4 cellspacing=1 border=0 id=tableborder align=center>\r\n\r\n<tr>\r\n<td id=title><div align=center>id</div></td>\r\n<td id=title><div align=center>User</div></td>\r\n<td id=title><div align=center>Password</div></td>\r\n<td id=title><div align=center>Can Template</div></td>\r\n<td id=title><div align=center>Can UserAdmin</div></td>\r\n<td id=title><div align=center>Delete</div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (30,'default','adminuserviewfooter','</table> <br>\r\n<br>\r\n<a href=\'$PHP_SELF?action=addform\'>Add New User</a> <br>\r\n<br>\r\n<a href=\'index.php\'>Main Page</a> ');
INSERT INTO templates VALUES (31,'default','adminuserchangepassform','<center>\r\n  Changing password for $name\r\n</center>\r\n<br><form method=POST action=\'$PHP_SELF?action=changepass\'>\r\n<input type=hidden name=id value=$id>\r\n<input type=hidden name=name value=$name>\r\n<input type=password name=\'password\' rows=0 cols=0></textarea>\r\n<br>\r\n<br>\r\n<input type=submit value=\'Send\'>\r\n<input type=reset value=\'Reset\'>\r\n');
INSERT INTO templates VALUES (32,'default','adminuserchangepass','<b>$name\'s</b> password was successfully changed.\r\n<br>\r\n<br>\r\n<a href=\'$PHP_SELF\'>back</a>');
INSERT INTO templates VALUES (33,'default','adminuseradd','<b>$name</b> was added to the admin users. <br>\r\n<br>\r\n<a href=\'$PHP_SELF\'>back</a>');
INSERT INTO templates VALUES (34,'default','adminuserconfirmdelete','Are you sure you want to remove <b>$name</b> from the admin users? <br>\r\n<br>\r\n<a href=\'$PHP_SELF?action=delete&id=$id&name=$name\'>Yes</a> <br>\r\n<br>\r\n<a href=\'$PHP_SELF\'>no</a>');
INSERT INTO templates VALUES (35,'default','adminuserdelete','$name was removed from the admin users. <br>\r\n<br>\r\n<a href=\'$PHP_SELF\'>back</a>');
INSERT INTO templates VALUES (36,'default','statusheader','<center>\r\n');
INSERT INTO templates VALUES (37,'default','statuschanged','Ticket <b> #$tid</b> status has been set to <b>$status</b>');
INSERT INTO templates VALUES (38,'default','statusnotchanged','You need to specify a tid and status of open or closed');
INSERT INTO templates VALUES (39,'default','statusfooter','<br>\r\n<br>\r\n<a href=\'ticketview.php?tid=$tid\'>Back to the ticket</a>\r\n<br>\r\n<br>\r\n<a href=\'ticketlist.php?by=tid\'>Ticket List</a>\r\n</center>');
INSERT INTO templates VALUES (40,'default','clientticketlistheader','<p>$status Trouble Tickets: $num_results</p>\r\n<table width=\'85%\' cellpadding=4 cellspacing=1 border=0 id=tableborder>\r\n<tr>\r\n<td id=title><div align=center><a href=\'ticketlist.php?by=tid&status=$status\'>Ticket ID</a> <a href=\'ticketlist.php?by=tid&status=$status&order=asc\'><img src=\'images/order.gif\' border=0 ALT=\'Reverse Order\'></a></div></td>\r\n<td id=title><div align=center><a href=\'ticketlist.php?by=domain&status=$status\'>Domain</a></div></td>\r\n<td id=title><div align=center><a href=\'ticketlist.php?by=subject&status=$status\'>Subject</a></div></td>\r\n<td id=title><div align=center><a href=\'ticketlist.php?by=priority_level&status=$status\'>Priority</a></div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (41,'default','ticketlistbody','<tr>\r\n<td id=content><div align=center><a href=\'ticketview.php?tid=$tid\'>$tid</a></div></td>\r\n<td id=content><div align=center>$domain</div></td>\r\n<td id=content><div align=center>$subject</div></td>\r\n<td id=content><div align=center>$priority_level</div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (42,'default','ticketlistfooter','</table>\r\n<br>\r\n<br>\r\n<a href=\'index.php\'>Main Page</a>');
INSERT INTO templates VALUES (43,'default','ticketreplysent','Your reply has been sent to ticket #: <b>$tid</b> and has been set to <b>$status</b>.\r\n<br>\r\n<br>\r\n<a href=\'ticketlist.php?by=tid\'>Ticket List</a> or <a href=\'ticketview.php?tid=$tid\'>Back to the Trouble Ticket</a>\r\n');
INSERT INTO templates VALUES (44,'default','ticketviewheader','<table width=\'55%\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n        <tr>\r\n                <td colspan=2  id=\'title\'><b>Ticket ID: $tid</b></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Name:</td>\r\n                <td id=\'content\'>$name</td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Email:</td>\r\n                <td id=\'content\'><a href=\'mailto:$email?subject=Ticket #: $tid\'>$email</a></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Subject:</td>\r\n                <td id=\'content\'>$subject</td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Priority:</td>\r\n                <td id=\'content\'>$priority_level</td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Domain:</td>\r\n                <td id=\'content\'><a href=\'http://$info[domain]\'target=\'_blank\'>$domain</a></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Status:</td>\r\n                <td id=\'content\'>$status</td>\r\n        </tr>\r\n</table><br>\r\n<script language=\'JavaScript\'>\r\nfunction getActiveText(selectedtext) {\r\n        text = (document.all) ? document.selection.createRange().text : document.getSelection();\r\n        if (selectedtext.createTextRange) {\r\n        selectedtext.caretPos = document.selection.createRange().duplicate();\r\n        }\r\n        return true;\r\n}\r\nfunction quick(Quick) {\r\nif (Quick != 0) {\r\n        if (document.reply.response.createTextRange && document.reply.response.caretPos) {\r\n                var caretPos = document.reply.response.caretPos;\r\n                caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == \' \' ? Quick + \' \' : Quick;\r\n        } else {\r\n                document.reply.response.value+=Quick\r\n        }\r\n        document.reply.response.focus();\r\n        document.reply.quickselect.selectedIndex = 0;\r\n}\r\n}\r\n</script>\r\n');
INSERT INTO templates VALUES (45,'default','ticketviewquestion','<table width=\'600\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n        <tr>\r\n                <td colspan=2  id=\'title\'><b>Dialog</b></td>\r\n        </tr>\r\n        <tr>\r\n                <td colspan=2  id=\'content\'><font size=1><b>Initial Question sent on $requestdate $requesttime</b><font><hr>$question</td>\r\n        </tr>\r\n');
INSERT INTO templates VALUES (46,'default','ticketviewnotes','<br>\r\n<br>\r\n<hr><font size=1 color=\'#0000FF\'><b>Staff Notes: $staffuser added this note on $notedate $notetime</b></font><hr>$notes\r\n                        ');
INSERT INTO templates VALUES (47,'default','ticketviewwrote','    <tr>\r\n                        <td id=\'content\'><font size=1 color=\'#0000FF\'><b>On $replydate $replytime, $staffuser wrote:</b></font><hr>$responsetext\r\n');
INSERT INTO templates VALUES (48,'default','ticketviewreplyform','</table>\r\n<form name=reply method=POST action=\'ticketreply.php\'>\r\n<table width=\'75%\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n        <tr>\r\n                <td colspan=2  id=\'title\'><b>Respond</b></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Response:</td>\r\n                <td id=\'content\'><textarea name=\'response\' rows=10 cols=77 wrap=hard onChange=getActiveText(this) onclick=getActiveText(this) onFocus=getActiveText(this) ></textarea><br>\r\n                <select onChange=\'quick(this.options[this.selectedIndex].value)\' name=\'quickselect\'>\r\n                <option value=\'0\'>Quick Response</option>\r\n                <option>-----------</option>\r\n                $quickreply\r\n                </select></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Check Spelling:</td>\r\n                <td id=\'content\'><select name=\'spelling\'>\r\n                <option value=\'no\'>No</option>\r\n                <option value=\'yes\'>Yes</option></select></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Status:</td>\r\n                <td id=\'content\'><select name=\'status\'>\r\n                <option value=\'WOC\'>WOC</option>\r\n                <option value=\'Open\'>Open</option>\r\n                <option value=\'Closed\'>Closed</option></select></td>\r\n        </tr>\r\n        <tr>\r\n                <td id=\'title\'></td>\r\n                <td id=\'title\'><input type=hidden name=email value=\'$email\'><input type=hidden name=tid value=\'$tid\'><input type=hidden name=action value=send><input type=submit value=\'Send\'> <input type=reset value=\'Reset\'></td>\r\n        </tr>\r\n</table>\r\n</form>\r\n<center><a href=\'ticketlist.php?by=tid\'>Ticket List</a>\r\n<br><br>\r\n<a href=\'index.php\'>Main Page</a>\r\n</center>');
INSERT INTO templates VALUES (49,'default','ticketviewaddnote','<table width=\'75%\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n<form name=reply method=POST action=\'addticketnote.php\'>\r\n<tr>\r\n                <td align=\'right\' id=\'content\'>Notes:<br><font size=1>Will not be seen by the client.</font></td>\r\n                <td id=\'content\'><textarea name=\'notes\' rows=10 cols=77 wrap=hard></textarea></td>\r\n		<td id=\'title\'><input type=hidden name=tid value=\'$tid\'><br><input type=submit value=\'AddNote\'> <input type=reset value=\'Reset\'></td>\r\n        </tr>\r\n</table>\r\n</form>\r\n\r\n<center><a href=\'ticketlist.php?by=tid\'>Ticket List</a>\r\n<br><br>\r\n<a href=\'index.php\'>Main Page</a>\r\n</center>\r\n');
INSERT INTO templates VALUES (50,'default','ticketviewstatuswoc','Use this link to change ticket status without replying.\r\n<br>\r\n<br>\r\n<a href=\'status.php?tid=$tid&status=Closed\'>Close Ticket</a>');
INSERT INTO templates VALUES (51,'default','ticketviewstatusopen','Use this link to change ticket status without replying.\r\n<br>\r\n<br>\r\n<a href=\'status.php?tid=$tid&status=Closed\'>Close Ticket</a>');
INSERT INTO templates VALUES (52,'default','ticketviewstatusclosed','Use this link to change ticket status without replying.\r\n<br>\r\n<br>\r\n<a href=\'status.php?tid=$tid&status=Open\'>Open Ticket</a>');
INSERT INTO templates VALUES (53,'default','templateviewfooter','</table>\r\n<br><br>\r\n<a href=\'$PHP_SELF?action=addform\'>Add New</a>\r\n<br><br>\r\n<a href=\'index.php\'>Main Page</a>');
INSERT INTO templates VALUES (54,'default','templateviewbody','<tr>\r\n<td id=content><div align=center><a href=\'$PHP_SELF?action=edit&templateid=$templateid\'>$templateid</a></div></td>\r\n<td id=content><div align=center><a href=\'$PHP_SELF?action=edit&templateid=$templateid\'>$name</a></div></td>\r\n<td id=content><div align=center>$groupname</div></td>\r\n<td id=content><div align=center><a href=\'$PHP_SELF?action=confirm&templateid=$templateid&name=$name&groupname=$groupname\'>Delete</a></div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (55,'default','templateviewheader','<p>\r\n<center>\r\nTotal Templates: $num_results\r\n</center>\r\n</p>\r\n\r\n<table width=\'50%\' cellpadding=4 cellspacing=1 border=0 id=tableborder align=center>\r\n\r\n<tr>\r\n<td id=title><div align=center>Template ID</div></td>\r\n<td id=title><div align=center>Name</div></td>\r\n<td id=title><div align=center>GroupName</div></td>\r\n<td id=title><div align=center>Delete</div></td>\r\n</tr>\r\n\r\n');
INSERT INTO templates VALUES (56,'default','adminuserpermissions','<form action=\'$PHP_SELF\' method=\'post\'>\r\n  <input type=hidden name=\'action\' value=\'updatepermissions\'>\r\n  <input type=hidden name=\'name\' value=\'$name\'>\r\n  <input type=hidden name=\'id\' value=\'$id\'>\r\n  Can use the template manager<br>\r\n  <select name=\'cantemplate\'>\r\n    <option value=\'$cantemplate\' >Currently set to $cantemplate</option>\r\n    <option value=\'Y\'>Yes</option>\r\n    <option value=\'N\'>No</option>\r\n  </select>\r\n  <br>\r\n  Can user the admin user manager<br>\r\n  <select name=\'canuseradmin\'>\r\n    <option value=\'$canuseradmin\'>Currently set to $canuseradmin</option>\r\n    <option value=\'Y\'>Yes</option>\r\n    <option value=\'N\'>No</option>\r\n  </select>\r\n  <br>\r\n  <input type=submit value=\'Modify Permssions\'>\r\n  <input type=reset value=\'Reset\'>\r\n</form>\r\n');
INSERT INTO templates VALUES (57,'default','templateedit','<form method=\'post\' action=\'$PHP_SELF\'> \r\n<input type=hidden name=\'action\' value=\'send\'>\r\n<input type=hidden name=\'templateid\' value=\'$templateid\'>\r\nTemplate Name <br>\r\n<input type=text name=\'templatename\' rows=0 cols=0 value=\'$templatename\'></textarea> \r\n<br>\r\nGroup Name <br>\r\n<input type=text name=\'groupname\' rows=0 cols=0 value=\'$groupname\'></textarea> \r\n<br><textarea name=\'code\' rows=45 cols=140 >$code</textarea>\r\n<br>\r\n<input type=submit value=\'Send\'>\r\n<input type=reset value=\'Reset\'>\r\n<br>\r\n<br>\r\n<a href=\'$PHP_SELF\'>Back to Template Manager</a>');
INSERT INTO templates VALUES (58,'default','styleupdated','Style #: <b>$styleid</b> has been updated\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back to Template Manager</a>');
INSERT INTO templates VALUES (59,'default','accessdenied','Sorry, you do not have access to this area of the ticket system. <br>\r\n<br>\r\n<a href=\'javascript:history.back();\'>Back</a>');
INSERT INTO templates VALUES (60,'default','templateaddform','<form method=POST action=\'$PHP_SELF\'>\r\n<input type=hidden name=action value=add>\r\nTemplate Name\r\n<br>\r\n<input type=text name=\'templatename\' rows=0 cols=0 ></textarea><br>\r\nGroup Name\r\n<br>\r\n<input type=text name=\'groupname\' rows=0 cols=0 value=\'default\'></textarea><br>\r\n<textarea name=\'code\' rows=45 cols=110 value=></textarea><br>\r\n<input type=submit value=\'Send\'> <input type=reset value=\'Reset\'>\r\n<br><br>\r\n<a href=\'$PHP_SELF\'>Back to Template Manager</a>');
INSERT INTO templates VALUES (61,'default','templateadded','<b>$templatename</b> was added to the templates in the group named <b>$groupname</b>.');
INSERT INTO templates VALUES (62,'default','templateconfirmdelete','Are you sure you wan to delete the template <b>$name</b> from the group <b>$groupname</b>?\r\n<br>\r\n<br>\r\n<a href=\'$PHP_SELF?action=delete&templateid=$templateid&name=$name&groupname=$groupname\'>Yes</a>\r\n<br>\r\n<a href=\'$PHP_SELF\'>No</a>');
INSERT INTO templates VALUES (63,'default','templatedeleted','The template <b>$name</b> in the group <b>$groupname</b> was deleted.\r\n<br>\r\n<a href=\'$PHP_SELF\'>Back to the Template Manager</a>');
INSERT INTO templates VALUES (64,'default','adminuserupdatepermissions','The permissions for <b>$name</b> where updated.\r\n<br>\r\n<br>\r\n<a href=\'$PHP_SELF\'>Back to the Admin User Manager</a>');
INSERT INTO templates VALUES (65,'default','publicheader','<html>\r\n<title>Ticket System - $pagetitle</title>\r\n<head>\r\n<STYLE TYPE=\'TEXT/CSS\'>\r\n$css\r\n</STYLE>\r\n</head>\r\n<center>');
INSERT INTO templates VALUES (66,'default','publicfooter','<br><br>\r\n<font size=1>Powered by: TicketOne Alpha 1.4<br>\r\nCopyright � 2002 LinuxGroup.net</font>\r\n</body>\r\n</center>\r\n</html>');
INSERT INTO templates VALUES (67,'default','banned','Sorry, you have been banned from the ticket system.');
INSERT INTO templates VALUES (68,'default','clientfooter','<br>\r\n<br>\r\n<font size=1>Powered by: TicketOne Alpha 1.4<br>\r\nCopyright � 2002 LinuxGroup.net</font> \r\n</body></center>\r\n</html>\r\n');
INSERT INTO templates VALUES (69,'default','clientindex','<p><a href=\'ticketlist.php\'>Open Tickets</a><br>\r\n  <br>\r\n  <a href=\'ticketlist.php?status=Closed\'>Closed Tickets</a> <br>\r\n  <br>\r\n  <a href=\'preferences.php\'>User Preferences</a><br>\r\n  <br>\r\n</p>\r\n<p><a href=\'ticket.php\'>Submit New Ticket</a><br>\r\n  <br>\r\n  <br>\r\n  <br>\r\n  <br>\r\n  <strong>User Information</strong>:<br>\r\n  User ID :<b> $auth_row[cid]</b> <br>\r\n  User name :<b> $auth_row[username]</b> <br>\r\n  <br>\r\n</p>\r\n');
INSERT INTO templates VALUES (70,'default','clientheader','<html>\r\n<title>Ticket System - $pagetitle</title>\r\n<head>\r\n<STYLE TYPE=\'TEXT/CSS\'>\r\n$css\r\n</STYLE>\r\n</head><center>\r\n<body>\r\n<table width=\'91%\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n  <tr>\r\n    <td id=\'title\'>Trouble Ticket Admistrtion</td>\r\n    <td id=\'title\'>View all your opened tickets.</td>\r\n    <td id=\'title\'>View all your closed tickets.</td>\r\n  </tr>\r\n  <tr> \r\n    <td width=\'13%\' id=\'content\'><a href=\'ticket.php\'>Submit New</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'ticketlist.php\'>View Opened</a></td>\r\n    <td width=\'13%\' id=\'content\'><a href=\'ticketlist.php?status=Closed\'>View Closed</a></td>\r\n  </tr>\r\n</table>\r\n<br>\r\n<br>\r\n');
INSERT INTO templates VALUES (71,'default','clientticketlistbody','<tr>\r\n<td id=content><div align=center><a href=\'ticketview.php?tid=$tid\'>$tid</a></div></td>\r\n<td id=content><div align=center>$domain</div></td>\r\n<td id=content><div align=center>$subject</div></td>\r\n<td id=content><div align=center>$priority_level</div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (72,'default','clientticketlistfooter','</table>\r\n<br>\r\n<br>\r\n<a href=\'index.php\'>Main Page</a>');
INSERT INTO templates VALUES (73,'default','clientstatusheader','<center>\r\n');
INSERT INTO templates VALUES (74,'default','clientstatusnotchanged','You need to specify a tid and status of open or closed');
INSERT INTO templates VALUES (75,'default','clientstatuschanged','Ticket <b> #$tid</b> status has been set to <b>$status</b>');
INSERT INTO templates VALUES (76,'default','clientstatusfooter','<br>\r\n<br>\r\n<a href=\'ticketview.php?tid=$tid\'>Back to the ticket</a>\r\n<br>\r\n<br>\r\n<a href=\'ticketlist.php?by=tid\'>Ticket List</a>\r\n</center>');
INSERT INTO templates VALUES (77,'default','clientticketreplysent','Your reply has been sent to ticket #: <b>$tid</b> and has been set to <b>$status</b>.\r\n<br>\r\n<br>\r\n<a href=\'ticketlist.php?by=tid\'>Ticket List</a> or <a href=\'ticketview.php?tid=$tid\'>Back to the Trouble Ticket</a>\r\n');
INSERT INTO templates VALUES (78,'default','clientticketviewheader','<table width=\'55%\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n        <tr>\r\n                <td colspan=2  id=\'title\'><b>Ticket ID: $tid</b></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Name:</td>\r\n                <td id=\'content\'>$name</td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Email:</td>\r\n                <td id=\'content\'><a href=\'mailto:$email?subject=Ticket #: $tid\'>$email</a></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Subject:</td>\r\n                <td id=\'content\'>$subject</td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Priority:</td>\r\n                <td id=\'content\'>$priority_level</td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Domain:</td>\r\n                <td id=\'content\'><a href=\'http://$info[domain]\'target=\'_blank\'>$domain</a></td>\r\n        </tr>\r\n        <tr>\r\n                <td align=\'right\' id=\'content\'>Status:</td>\r\n                <td id=\'content\'>$status</td>\r\n        </tr>\r\n</table><br>\r\n<script language=\'JavaScript\'>\r\nfunction getActiveText(selectedtext) {\r\n        text = (document.all) ? document.selection.createRange().text : document.getSelection();\r\n        if (selectedtext.createTextRange) {\r\n        selectedtext.caretPos = document.selection.createRange().duplicate();\r\n        }\r\n        return true;\r\n}\r\nfunction quick(Quick) {\r\nif (Quick != 0) {\r\n        if (document.reply.response.createTextRange && document.reply.response.caretPos) {\r\n                var caretPos = document.reply.response.caretPos;\r\n                caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == \' \' ? Quick + \' \' : Quick;\r\n        } else {\r\n                document.reply.response.value+=Quick\r\n        }\r\n        document.reply.response.focus();\r\n        document.reply.quickselect.selectedIndex = 0;\r\n}\r\n}\r\n</script>\r\n');
INSERT INTO templates VALUES (79,'default','clientticketviewquestion','<table width=\'600\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n        <tr>\r\n                <td colspan=2  id=\'title\'><b>Dialog</b></td>\r\n        </tr>\r\n        <tr>\r\n                <td colspan=2  id=\'content\'><font size=1><b>Initial Question sent on $requestdate $requesttime</b><font><hr>$question</td>\r\n        </tr>\r\n');
INSERT INTO templates VALUES (80,'default','clientticketviewwrote','    <tr>\r\n                        \r\n  <td id=\'content\'><font size=1 color=\'#000000\'><strong>On $replydate $replytime, \r\n    $staffuser wrote:</strong></font> \r\n<hr>$responsetext\r\n');
INSERT INTO templates VALUES (81,'default','clientticketviewreplyform','</table> \r\n<br>\r\n<br>\r\n<form name=reply method=POST action=\'ticketreply.php\'>\r\n  <table width=\'75%\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n    <tr> \r\n      <td colspan=2  id=\'title\'><b>Respond</b></td>\r\n    </tr>\r\n    <tr> \r\n      <td align=\'right\' id=\'content\'>Response:</td>\r\n      <td id=\'content\'><textarea name=\'response\' rows=10 cols=77 wrap=hard ></textarea> \r\n    </tr>\r\n    <tr> \r\n      <td id=\'title\'></td>\r\n      <td id=\'title\'><input type=hidden name=email value=\'$email\'> <input type=hidden name=tid value=\'$tid\'> \r\n        <input type=hidden name=action value=send> <input type=submit value=\'Send\'> \r\n        <input type=reset value=\'Reset\'></td>\r\n    </tr>\r\n  </table>\r\n</form>\r\n<center>\r\n  <a href=\'ticketlist.php?by=tid\'>Ticket List</a> <br>\r\n  <br>\r\n  <a href=\'index.php\'>Main Page</a> \r\n</center>\r\n');
INSERT INTO templates VALUES (82,'default','clientsubmitticketform','<form method=POST action=\'newticket.php\'>\r\n  <table width=\'600\' cellpadding=4 cellspacing=1 border=0 id=\'tableborder\'>\r\n    <tr> \r\n      <td colspan=2 id=\'title\'><b>Submit Trouble Ticket</b> <font color=\'#FF0000\'>$error</font></td>\r\n    </tr>\r\n    <tr> \r\n      <td align=\'right\' id=\'content\'>Name:</td>\r\n      <td id=\'content\'><input type=text name=\'name\' value=\'$clientname\' size=30></td>\r\n    </tr>\r\n    <tr> \r\n      <td align=\'right\' id=\'content\'>Email:</td>\r\n      <td id=\'content\'><input type=text name=\'email\' value=\'$clientemail\' size=30></td>\r\n    </tr>\r\n    <tr> \r\n      <td align=\'right\' id=\'content\'>Subject:</td>\r\n      <td id=\'content\'><input type=text name=\'subject\' value=\'$subject\' size=30></td>\r\n    </tr>\r\n    <tr> \r\n      <td align=\'right\' id=\'content\'>Priority:</td>\r\n      <td id=\'content\'><select name=\'priority\'>\r\n          <option value=\'Low\' $priority3>Low</option>\r\n          <option value=\'Medium\' $priority2>Medium</option>\r\n          <option value=\'High\' $priority1>High</option>\r\n        </select></td>\r\n    </tr>\r\n    <tr> \r\n      <td align=\'right\' id=\'content\'>Domain:</td>\r\n      <td id=\'content\'><input type=text name=\'domain\' value=\'$clientdomain\' size=30></td>\r\n      </td>\r\n    </tr>\r\n    <tr> \r\n      <td align=\'right\' id=\'content\'>Question:</td>\r\n      <td id=\'content\'><textarea name=\'question\' rows=10 cols=77 wrap=hard>$question</textarea></td>\r\n    </tr>\r\n    <tr> \r\n      <td id=\'title\'></td>\r\n      <td id=\'title\'><input type=hidden name=mode value=send>\r\n        <input type=submit value=\'Send\'> <input type=reset value=\'Reset\'></td>\r\n    </tr>\r\n  </table>\r\n</form>\r\n');
INSERT INTO templates VALUES (83,'default','clientticketviewstatusopen','<br>\r\nUse this link to change ticket status without replying.\r\n<br>\r\n<br>\r\n<a href=\'status.php?tid=$tid&status=Closed\'>Close Ticket</a>');
INSERT INTO templates VALUES (84,'default','clientticketaccountsheader','Select an account below\r\n<br>\r\n<form action=\'newticket.php\' method=\'post\'>\r\n<select name=\'clientdomain\'>');
INSERT INTO templates VALUES (85,'default','clientticketaccountsfooter','</select>\r\n<input type=\'submit\' value=\'Go\'>\r\n</form>');
INSERT INTO templates VALUES (86,'default','ticketlistheader','<p>$status Trouble Tickets: $num_results</p>\r\n<table width=\'85%\' cellpadding=4 cellspacing=1 border=0 id=tableborder>\r\n<tr>\r\n<td id=title><div align=center><a href=\'ticketlist.php?by=tid&status=$status\'>Ticket ID</a> <a href=\'ticketlist.php?by=tid&status=$status&order=asc\'><img src=\'images/order.gif\' border=0 ALT=\'Reverse Order\'></a></div></td>\r\n<td id=title><div align=center><a href=\'ticketlist.php?by=domain&status=$status\'>Domain</a></div></td>\r\n<td id=title><div align=center><a href=\'ticketlist.php?by=subject&status=$status\'>Subject</a></div></td>\r\n<td id=title><div align=center><a href=\'ticketlist.php?by=priority_level&status=$status\'>Priority</a></div></td>\r\n</tr>');
INSERT INTO templates VALUES (87,'default','clientpreferencesviewheader','<p> \r\n  <center>\r\n    <p>Available Styles: $num_results </p>\r\n    <p>Your current style is set to <strong>$current_style</strong>.</p>\r\n  </center>\r\n</p><table width=\'50%\' cellpadding=4 cellspacing=1 border=0 id=tableborder align=center> \r\n<tr> \r\n  <td id=title><div align=center>Name</div></td>\r\n  <td id=title><div align=center>Set Style</div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (88,'default','clientpreferencesviewbody','<tr> \r\n  <td id=content><div align=center>$name</div></td>\r\n  <td id=content><div align=center><a href=\'$PHP_SELF?action=set&styleid=$styleid\'>Set</a></div></td>\r\n</tr>\r\n');
INSERT INTO templates VALUES (89,'default','clientpreferencesupdated','Your preferences have been updated. <br>Click <a href=\'$PHP_SELF\'>here</a> to return to your settings.');
INSERT INTO templates VALUES (90,'default','test','$coded');

--
-- Table structure for table 'tickets'
--

CREATE TABLE tickets (
  tid mediumint(8) NOT NULL auto_increment,
  cid bigint(20) default NULL,
  name varchar(100) NOT NULL default '',
  email varchar(100) NOT NULL default '',
  domain varchar(100) NOT NULL default '',
  subject varchar(100) NOT NULL default '',
  status enum('Open','Closed','WOC') NOT NULL default 'Open',
  priority_level varchar(6) NOT NULL default '',
  request text NOT NULL,
  requestdate date NOT NULL default '0000-00-00',
  requesttime time default NULL,
  ipaddress varchar(15) NOT NULL default '',
  PRIMARY KEY  (tid),
  KEY name (name),
  KEY domain (domain)
) TYPE=MyISAM;

--
-- Dumping data for table 'tickets'
--



--
-- Table structure for table 'users'
--

CREATE TABLE users (
  name varchar(12) NOT NULL default '',
  password varchar(32) NOT NULL default '',
  signature tinytext NOT NULL,
  id int(11) NOT NULL auto_increment,
  cantemplate enum('N','Y') NOT NULL default 'Y',
  canuseradmin enum('N','Y') NOT NULL default 'Y',
  PRIMARY KEY  (id),
  UNIQUE KEY name (name)
) TYPE=MyISAM;

--
-- Dumping data for table 'users'
--


INSERT INTO users VALUES ('admin','21232f297a57a5a743894a0e4a801fc3','-Joe Admin',1,'Y','Y');

