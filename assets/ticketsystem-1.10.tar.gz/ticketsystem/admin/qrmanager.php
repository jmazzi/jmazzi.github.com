<?php
    /* $Id: qrmanager.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require('config.php');
     
    pageheader("Quick Response Manager");
     
    if (!$action || $action == '') {
        $action = "view";
    }
     
    if ($action == "view") {
        $sql = "select qid, name, response from qw_response order by qid";
        $result = mysql_query($sql);
        $num_results = mysql_num_rows($result);
        eval("output(\"".template("qrviewheader")."\");");
         
        while ($info = mysql_fetch_array($result)) {
            $qid = ($info['qid']);
            $name = ($info['name']);
             
            eval("output(\"".template("qrviewbody")."\");");
        }
         
        eval("output(\"".template("qrviewfooter")."\");");
    }
     
    if ($action == "edit") {
        $sql = "select response from qw_response where qid ='$qid'";
        $result = mysql_query($sql);
        $response = mysql_result($result, 0);
        $sql = "select name from qw_response where qid ='$qid'";
        $result = mysql_query($sql);
        $name = mysql_result($result, 0);
         
        eval("output(\"".template("qredit")."\");");
    }
     
    if ($action == "send") {
        mysql_query("update qw_response set response='$response', name='$name' where qid='$qid'");
         
        eval("output(\"".template("qrsend")."\");");
    }
     
    if ($action == "addform") {
        eval("output(\"".template("qraddform")."\");");
    }
     
    if ($action == "add") {
        mysql_query("insert into qw_response (name, response) values ('$name', '$response')");
        eval("output(\"".template("qradd")."\");");
    }
     
    if ($action == "confirm") {
        eval("output(\"".template("qrconfirmdelete")."\");");
    }
     
    if ($action == "delete") {
        mysql_query("delete from qw_response where qid ='$qid'");
        eval("output(\"".template("qrdeleted")."\");");
    }
     
?>
