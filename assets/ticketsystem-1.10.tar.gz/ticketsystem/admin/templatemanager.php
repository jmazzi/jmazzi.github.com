<?php
    /* $Id: templatemanager.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require('config.php');
     
    if ($usercantemplate == "N") {
        eval("output(\"".template("accessdenied")."\");");
        exit;
    }
     
    pageheader("Template Manager");
     
    if (!$action || $action == '') {
        $action = "view";
    }
     
    if ($action == "view") {
        $sql = "select templateid, name, groupname from templates order by name";
        $result = mysql_query($sql);
        $num_results = mysql_num_rows($result);
        eval("output(\"".template("templateviewheader")."\");");
         
        while ($info = mysql_fetch_array($result)) {
            $templateid = ($info['templateid']);
            $name = ($info['name']);
            $groupname = ($info['groupname']);
            eval("output(\"".template("templateviewbody")."\");");
        }
        eval("output(\"".template("templateviewfooter")."\");");
    }
     
    if ($action == "edit") {
        $sql = "select name, groupname, code from templates where templateid ='$templateid'";
        $result = mysql_query($sql);
        $info = mysql_fetch_array($result);
        $templatename = $info['name'];
        $groupname = $info['groupname'];
         
        $sql = "select code from templates where templateid ='$templateid'";
        $result = mysql_query($sql);
        $code = mysql_result($result, 0);
        $code = htmlspecialchars($code);
        eval("output(\"".template("templateedit")."\");");
    }
     
    if ($action == "send") {
        mysql_query("update templates set code='$code', name='$templatename', groupname='$groupname' where templateid='$templateid'");
        eval("output(\"".template("templateupdated")."\");");
    }
     
    if ($action == "addform") {
        eval("output(\"".template("templateaddform")."\");");
    }
     
    if ($action == "add" && $code) {
        mysql_query("insert into templates (name, code, groupname) values ('$templatename', '$code', '$groupname')");
        eval("output(\"".template("templateadded")."\");");
    }
     
    if ($action == "confirm") {
        eval("output(\"".template("templateconfirmdelete")."\");");
    }
     
    if ($action == "delete" && $templateid && $groupname && $name) {
        mysql_query("delete from templates where templateid='$templateid' and groupname='$groupname' and name='$name'");
        eval("output(\"".template("templatedeleted")."\");");
    }
     
?>
