<?php
    /* $Id: ticketreply.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require "config.php";
     
    pageheader("Reply to Trouble Ticket");
     
    if ($action == "send") {
        $response = htmlspecialchars($response);
        $sql = "insert into responses (tid, staffuser, response, replydate, replytime) values ('$tid', '$PHP_AUTH_USER', '$response', now(), now())";
        mysql_query($sql);
        mysql_query("update tickets set status='$status' where tid='$tid'");
        $emaildate = date("F j, Y, g:i a");
        mail("$email", "Response for Ticket $tid on $emaildate", $response , "From: $supportname<$supportemail>");
        eval("output(\"".template("ticketreplysent")."\");");
    }
     
    pagefooter();
     
?>
