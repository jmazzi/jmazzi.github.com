<?php
    /* $Id: ticketview.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require 'config.php';
     
    if (!$tid) header("location: ticketlist.php?by=tid");
     
    pageheader("Trouble Ticket #$tid");
     
    $signature = $auth_row[signature];
     
    $sql = "select tid, name, email, domain, subject, status, priority_level, request, requestdate, requesttime from tickets where tid = '$tid'";
    $result = mysql_query($sql);
     
    while ($info = mysql_fetch_array($result)) {
        $requesttime = $info[requesttime];
        $requestdate = $info[requestdate];
        $sql = "select qid, name, response from qw_response";
        $result = mysql_query($sql);
        while ($quickresponses = mysql_fetch_array($result)) {
            $text = str_replace("\'", "'", $quickresponses[response]);
            $quickreply  .= "<option value='$text'>$quickresponses[name]</option>\n";
        }
        $name = $info[name];
        $email = $info[email];
        $subject = $info[subject];
        $priority_level = $info[priority_level];
        $domain = $info[domain];
        $status = $info[status];
        eval("output(\"".template("ticketviewheader")."\");");
         
        $sql = "select tid, staffuser, response, replydate, replytime from responses where tid = '$tid'";
        $result = mysql_query($sql);
        $question = nl2br($info[request]);
        eval("output(\"".template("ticketviewquestion")."\");");
         
        while ($info = mysql_fetch_array($result)) {
            $responsetext = nl2br($info[response]);
            $replytime = $info[replytime];
            $replydate = $info[replydate];
            $staffuser = $info[staffuser];
            eval("output(\"".template("ticketviewwrote")."\");");
        }
         
        $sql = "select tid, staffuser, notes, notedate, notetime from staffnotes where tid = '$tid'";
        $result = mysql_query($sql);
        while ($ticketnotes = mysql_fetch_array($result)) {
            $notes = $ticketnotes[notes];
            $notes = nl2br($notes);
            $notedate = $ticketnotes[notedate];
            $notetime = $ticketnotes[notetime];
            eval("output(\"".template("ticketviewnotes")."\");");
        }
        eval("output(\"".template("ticketviewreplyform")."\");");
        eval("output(\"".template("ticketviewaddnote")."\");");
         
        if ($status == "WOC") {
            eval("output(\"".template("ticketviewstatuswoc")."\");");
        }
         
        if ($status == "Open") {
            eval("output(\"".template("ticketviewstatusopen")."\");");
        }
         
        else if ($status == "Closed") {
            eval("output(\"".template("ticketviewstatusclosed")."\");");
        }
         
    }
     
    pagefooter();
     
?>
