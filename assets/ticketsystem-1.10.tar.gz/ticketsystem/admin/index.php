<?php
    /* $Id: index.php,v 1.5 2002/11/01 02:33:17 root Exp $ */
    if (file_exists('../install.php')) {
        die("Please remove install.php");
    }
     
    require "config.php";
     
    pageheader("Trouble Ticket Administration");
    eval("output(\"".template("adminindex")."\");");
     
    pagefooter();
     
?>
