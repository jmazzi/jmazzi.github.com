<?php
    /* $Id: usermanager.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require('config.php');
     
    if ($usercanuseradmin == "N") {
        eval("output(\"".template("accessdenied")."\");");
        exit;
    }
     
    pageheader("User Manager");
     
    if (!$action || $action == '') {
        $action = "view";
    }
     
    if ($action == 'view') {
        $sql = "select id, name, password, cantemplate, canuseradmin from users order by id";
        $result = mysql_query($sql);
        $num_results = mysql_num_rows($result);
        eval("output(\"".template("adminuserviewheader")."\");");
         
        while ($info = mysql_fetch_array($result)) {
            $id = ($info['id']);
            $name = ($info['name']);
            $password = ($info['password']);
            $cantemplate = ($info['cantemplate']);
            $canuseradmin = ($info['canuseradmin']);
             
            eval("output(\"".template("adminuserviewbody")."\");");
        }
        eval("output(\"".template("adminuserviewfooter")."\");");
    }
     
    if ($action == 'changepassform') {
        eval("output(\"".template("adminuserchangepassform")."\");");
    }
     
    if ($action == 'changepass') {
        mysql_query("update users set password=md5('$password') where id='$id'");
        eval("output(\"".template("adminuserchangepass")."\");");
    }
     
    if ($action == 'addform') {
        eval("output(\"".template("adminuseraddform")."\");");
    }
     
    if ($action == 'add' && $name && $password) {
        mysql_query("insert into users (name, password, cantemplate, canuseradmin) values ('$name', md5('$password'), '$cantemplate', '$canuseradmin')");
        eval("output(\"".template("adminuseradd")."\");");
    }
     
    if ($action == 'confirmdelete') {
        eval("output(\"".template("adminuserconfirmdelete")."\");");
    }
     
    if ($action == 'delete') {
        mysql_query("delete from users where id='$id'");
        eval("output(\"".template("adminuserdelete")."\");");
    }
     
    if ($action == 'permissions') {
        $sql = "select * from users where id='$id' and name='$name'";
        $result = mysql_query($sql);
        while ($info = mysql_fetch_array($result)) {
            $canuseradmin = $info['canuseradmin'];
            $cantemplate = $info['cantemplate'];
            eval("output(\"".template("adminuserpermissions")."\");");
        }
         
    }
     
    if ($action == "updatepermissions") {
        mysql_query("update users set cantemplate='$cantemplate', canuseradmin='$canuseradmin' where name='$name' and id='$id'");
        eval("output(\"".template("adminuserupdatepermissions")."\");");
    }
     
?>
