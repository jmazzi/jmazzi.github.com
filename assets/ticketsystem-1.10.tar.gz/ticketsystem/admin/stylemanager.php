<?php
    /* $Id: stylemanager.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require('config.php');
     
    pageheader("Style Manager");
     
    if (!$action || $action == '') {
        $action = "view";
    }
     
    if ($action == "view") {
        $sql = "select styleid, name, code from styles order by styleid";
        $result = mysql_query($sql);
        $num_results = mysql_num_rows($result);
        eval("output(\"".template("styleviewheader")."\");");
         
        while ($info = mysql_fetch_array($result)) {
            $styleid = ($info['styleid']);
            $name = ($info['name']);
            eval("output(\"".template("styleviewbody")."\");");
        }
        $sql = "select style from config";
        $result = mysql_query($sql);
        $output = mysql_result($result, 0);
         
        $sql = "select name from styles where styleid = '$output'";
        $result = mysql_query($sql);
        $style = mysql_result($result, 0);
        eval("output(\"".template("styleviewfooter")."\");");
    }
     
    if ($action == "edit") {
        $sql = "select name, groupname from styles where styleid ='$styleid'";
        $result = mysql_query($sql);
        $info = mysql_fetch_array($result);
        $name = $info['name'];
        $groupname = $info['groupname'];
         
        $sql = "select code from styles where styleid ='$styleid'";
        $result = mysql_query($sql);
        $code = mysql_result($result, 0);
        eval("output(\"".template("styleedit")."\");");
    }
     
    if ($action == "send") {
        mysql_query("update styles set code='$code', name='$name' where styleid='$styleid'");
        eval("output(\"".template("styleupdated")."\");");
    }
     
    if ($action == "set") {
        mysql_query("update config set style='$styleid'");
        eval("output(\"".template("styleset")."\");");
    }
     
    if ($action == "addform") {
        eval("output(\"".template("styleaddform")."\");");
    }
     
    if ($action == "add") {
        mysql_query("insert into styles (groupname, name, code) values ('$groupname', '$name', '$code')");
        eval("output(\"".template("styleadded")."\");");
    }
     
    if ($action == "confirm") {
        eval("output(\"".template("styleconfirmdelete")."\");");
    }
     
    if ($action == "delete" && $styleid) {
        mysql_query("delete from styles where styleid ='$styleid'");
        eval("output(\"".template("styledeleted")."\");");
    }
     
?>
