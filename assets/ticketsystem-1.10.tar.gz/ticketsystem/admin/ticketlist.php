<?php
    /* $Id: ticketlist.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require "config.php";
     
    pageheader("Trouble Tickets List");
     
    if (!$status || $status == '') {
        $status = "Open";
    }
     
    if (!$order || $order == '') {
        $order = "desc";
    }
     
    if (!$by || $by == '') {
        $by = "tid";
    }
     
    $sql = "select tid, domain, subject, priority_level, status from tickets where status ='$status' order by $by $order";
    $result = mysql_query($sql);
    $num_results = mysql_num_rows($result);
    eval("output(\"".template("ticketlistheader")."\");");
     
    while ($info = mysql_fetch_array($result)) {
        $tid = ($info['tid']);
        $domain = ($info['domain']);
        $subject = ($info['subject']);
        $priority_level = ($info['priority_level']);
        eval("output(\"".template("ticketlistbody")."\");");
    }
     
    eval("output(\"".template("ticketlistfooter")."\");");
    pagefooter();
     
?>
