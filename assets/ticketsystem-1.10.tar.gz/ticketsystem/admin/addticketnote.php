<?php
    /* $Id: addticketnote.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require "config.php";
     
    pageheader("Ticket Not Added");
     
    if ($notes) {
        $notes = htmlspecialchars($notes);
        $sql = "insert into staffnotes (tid, staffuser, notes, notedate, notetime) values ('$tid', '$PHP_AUTH_USER', '$notes', now(), now())";
        mysql_query($sql);
        echo "notes added";
    }
     
    pagefooter();
     
?>
