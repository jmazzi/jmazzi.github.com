<?php
    /* $Id: admin_permissions.php,v 1.3 2002/11/01 02:33:18 root Exp $ */
     
    //CHECK PERMISSIONS
    $permssql = "select * from users where name='$PHP_AUTH_USER' limit 1";
    $permsresult = mysql_query($permssql);
    $permsinfo = mysql_fetch_array($permsresult);
     
    $usercantemplate = $permsinfo['cantemplate'];
    $usercanuseradmin = $permsinfo['canuseradmin'];
     
?>
