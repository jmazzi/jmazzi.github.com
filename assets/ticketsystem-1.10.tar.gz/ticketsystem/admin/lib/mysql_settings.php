<?php
     
    /* $Id: mysql_settings.php,v 1.4 2002/11/01 02:33:18 root Exp $ */
     
    //Hostname of the MySQL Sever
    $dbserver = "localhost";
    //Username to log into your Database
    $dbuser = "";
    //Password to log into your Database
    $dbpass = "";
    //Name of your Database
    $dbname = "";
    //SUPPORT EMAIL ADDRESS
    $supportemail = "support@DOMAIN";
    //SUPPORT NAME
    $supportname = "DOMAIN Support";
     
    //MAKE THE MYSQL CONNECTION
    mysql_connect($dbserver, $dbuser, $dbpass);
    mysql_select_db("$dbname");
?>
