<?php
     
    /* $Id: functions.php,v 1.4 2002/11/01 02:33:18 root Exp $ */
     
    // Gloabl functions //
    //QUICK TEMPLATE FUNCTION
    function template($name) {
        //FIGURE OUT THE TEMPLATE SET
        $sql = "select templateset from config";
        $result = mysql_query($sql);
        $output = mysql_result($result, 0);
         
        //GET THE REQUESTED TEMPLATE
        $sql = "select code, groupname from templates where name='$name' and groupname='$output'";
        $result = mysql_query($sql);
        $output = @mysql_result($result, 0);
        if (!$output) {
            echo "The template <b>$name</b> does not exsist!<br>\n";
        }
        $output = str_replace("\"", "\\\"", $output);
        return $output;
    }
     
    //ECHO THE REQUESTED TEMPLATE(used in conjuction with the template() function)
    function output($template) {
        echo $template;
    }
    //OUTPUT THE TEMPLATE FOR BEING BANNED
    function banned() {
        eval("output(\"".template("banned")."\");");
        exit;
    }
     
    //COMPARE THERE IP TO THE BANNED IPS
    function verify_ip($ip) {
        global $ban_ip;
         
        if ($ban_ip) {
            $ban_ip = explode("\n", preg_replace("/\s*\n\s*/", "\n", strtolower(trim($ban_ip))));
            for($i = 0; $i < count($ban_ip); $i++) {
                $ban_ip[$i] = trim($ban_ip[$i]);
                if (!$ban_ip[$i]) continue;
                if (strstr($ban_ip[$i], "*")) {
                    $ban_ip[$i] = str_replace("*", ".*", $ban_ip[$i]);
                    if (preg_match("/$ban_ip[$i]/i", $ip)) banned();
                }
                elseif($ip == $ban_ip[$i]) banned();
            }
        }
    }
    // End Gloabal //
     
     
    // Admin specific //
    //OUTPUT THE HEADER FOR A PAGE
    function pageheader($pagetitle) {
        //FIND CURRENT STYLE
        $sql = "select style from config";
        $result = mysql_query("select style from config");
        $style = mysql_result($result, 0);
         
        //OUTPUT THE STYLE
        $result = mysql_query("select code from styles where styleid = '$style'");
        $css = mysql_result($result, 0);
        eval("output(\"".template("adminheader")."\");");
    }
     
    //OUTPUT THE FOOTER FOR A PAGE
    function pagefooter() {
        eval("output(\"".template("adminfooter")."\");");
    }
    // End Admin //
     
     
    // Client specific //
    //OUTPUT THE HEADER FOR A CLIENT PAGE
    function clientpageheader($pagetitle) {
        global $auth_row;
        //FIND CURRENT STYLE
        if (!$auth_row[style]) {
            $sql = "select style from config";
            $result = mysql_query("select style from config");
            $style = mysql_result($result, 0);
        } else {
            $style = $auth_row[style];
        }
         
        //OUTPUT THE STYLE
        $result = mysql_query("select code from styles where styleid = '$style'");
        $css = @mysql_result($result, 0);
        eval("output(\"".template("clientheader")."\");");
    }
     
    //OUTPUT THE FOOTER FOR A CLIENT PAGE
    function clientpagefooter() {
        eval("output(\"".template("clientfooter")."\");");
    }
    // End Client //
     
?>
