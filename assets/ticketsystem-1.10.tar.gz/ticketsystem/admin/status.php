<?php
    /* $Id: status.php,v 1.4 2002/11/01 02:33:17 root Exp $ */
    require('config.php');
     
    pageheader("Change Ticket Status for TID #$tid");
    eval("output(\"".template("statusheader")."\");");
     
    $sql = "update tickets set status = '$status' where tid ='$tid'";
    $result = mysql_query($sql);
     
    if ($status == 'Closed') {
        $result;
        eval("output(\"".template("statuschanged")."\");");
    }
     
    else if ($status == 'Open') {
        $result;
        eval("output(\"".template("statuschanged")."\");");
    }
     
    else
        {
        eval("output(\"".template("statusnotchanged")."\");");
    }
     
    eval("output(\"".template("statusfooter")."\");");
    pagefooter();
     
?>
			
