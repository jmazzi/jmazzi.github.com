<?php
    /* $Id: config.php,v 1.6 2002/11/01 02:33:17 root Exp $ */
    require_once('./lib/mysql_settings.php');
    require_once('./lib/functions.php');
    require_once('./lib/admin_permissions.php');
     
    mysql_connect($dbserver, $dbuser, $dbpass);
    mysql_select_db("$dbname");
     
    $sql = "select ipaddress from banned ";
    $result = mysql_query($sql);
    $ban_ip = @mysql_result($result, 0);
    verify_ip($REMOTE_ADDR);
     
    if (!isset($PHP_AUTH_USER) || $PHP_AUTH_USER == "" || $PHP_AUTH_PW == "") {
        @Header("WWW-authenticate:  basic  realm='TicketOne Login'");
        @Header("HTTP/1.0  401  Unauthorized");
        echo "You  must  enter  a  valid  login  ID  and  password  to  access  this  resource\n";
        exit;
    } else {
        $auth_result = mysql_query("select name, signature, password, id from users where name ='$PHP_AUTH_USER' and password=md5('$PHP_AUTH_PW')");
        $auth_row = mysql_fetch_array($auth_result);
         
        if ($auth_row == 0) {
            @Header("WWW-authenticate:  basic  realm='TicketOne Login'");
            @Header("HTTP/1.0  401  Unauthorized");
            echo "You  must  enter  a  valid  login  ID  and  password  to  access  this  resource\n";
            exit;
        }
    }
     
?>
