<?php
    /* $Id: index.php,v 1.2 2002/11/01 02:33:16 root Exp $ */
    @header("Location:client/index.php");
?>
