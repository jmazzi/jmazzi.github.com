#!/usr/bin/php -q
<?php

require(dirname(__FILE__).'/includes/globals.php');

$dns->rebuildZones();

?>
