#!/usr/bin/php -q
<?php
    /*  $Id: gateway.php,v 1.11 2002/10/28 15:52:27 root Exp $
     *  Copyright (C) 2002 Justin Mazzi <justin@linuxgroup.net>
     *  This program is free software; you can redistribute it and/or modify
     *  it under the terms of the GNU General Public License as published by
     *  the Free Software Foundation; either version 2 of the License, or
     *  (at your option) any later version.
     *
     *  This program is distributed in the hope that it will be useful,
     *  but WITHOUT ANY WARRANTY; without even the implied warranty of
     *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *  GNU General Public License for more details.
     *
     *  You should have received a copy of the GNU General Public License
     *  along with this program; if not, write to the Free Software
     *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
     *  
     *  Dont forget to come by linuxgroup.net ;-)
     */
    
    /* Setup some vars */
    $stdin = fopen("php://stdin", "r");
     
    /* Fill the values in with your info */
    $sqlhost = "localhost";
    $sqluser = "";
    $sqlpass = "";
    $sqldb = "";
    
    /* This is used for bounced emails. */
    $support_email = "you@yourdomain.com";
    $support_name = "Your Name";
     
    /* make the mysql connection */
    mysql_connect($sqlhost, $sqluser, $sqlpass);
    mysql_select_db($sqldb);
     
    /* read in the pipe from stdin */
    while (!feof($stdin)) {
        $buffer = fgets($stdin, 4096);
        $message[] .= $buffer;
    }
     
    /* Get the email headers */
    foreach($message as $header_build) {
         
        if (preg_match("/^$/", $header_build)) break;
        $header_build = preg_replace("/:\s/", ":", $header_build);
        if (preg_match("/:/", $header_build)) {
            $vars = preg_split("/:/", $header_build, 2);
            if ($vars[1]) {
                chop($header[$vars[0]] = $vars[1]);
            }
        }
    }
     
    /* Error out if there's an attachment */
    if (preg_grep("/oundary=/", array_values($message))) {
        $attachment = 1;
        $email_body = "Hi,\n\tSorry, your message contained one or more attatchments. ";
        $email_body .= "Our email system does not currently accept ";
        $email_body .= "attachments. Please attempt to resend the email ";
        $email_body .= "without an attachment.\n\n -$support_name\n";
        $email_body .= "$support_email";
        $subject = "Re:$header[Subject]";
        $from = "From:<$support_name>$support_email";
        $to = $header['From'];
        mail($to, "$subject", "$email_body", $from);
        //exit("Message had an attachment");
    }
     
    /* strip out Re:'s in subject */
    if ($header['Subject']) {
        $header['Subject'] = preg_replace("/\s*Re:\s*/", "", $header['Subject']);
    }
     
    /* initialize Cc: header */
    if (!$header['Cc']) {
        $header['Cc'] = "";
    }
     
    /* fix empty subject header */
    $header['Subject']=preg_replace("/\n/","",$header['Subject']);
    if ($header['Subject']=="") {
        $header['Subject'] = "{no subject}";
    }
     
    /* Get the message body */
    for($i = count($header) + 1; $i <= count($message); $i++) {
        $body .= $message[$i];
    }
    if (preg_match("/^\n$/",$body)) {
        $body = "[empty message body]";
    } else {
        $body = mysql_escape_string($body);
    }
    if ($attachment>0) {
        $body="[message contained one or more attachments]";
    }
    $from = mysql_escape_string($header['From']);
    $cc = mysql_escape_string($header['Cc']);
    $subject = mysql_escape_string($header['Subject']);
     
    $query = "insert into emails (author, cc, subject, body, date, time) ";
    $query .= "values ('$from', '$cc', '$subject', '$body', now(), now())";
     
    mysql_query($query);
?>
