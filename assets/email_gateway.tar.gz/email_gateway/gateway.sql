--
-- Table structure for table 'emails'
--

CREATE TABLE emails (
  id bigint(20) NOT NULL auto_increment,
  author varchar(250) NOT NULL default '',
  cc varchar(250) NOT NULL default '',
  subject varchar(250) NOT NULL default '',
  body text NOT NULL,
  date date NOT NULL default '0000-00-00',
  time time NOT NULL default '00:00:00',
  PRIMARY KEY  (id),
  KEY author (author),
  KEY cc (cc),
  KEY subject (subject),
  KEY date (date),
  KEY time (time)
) TYPE=MyISAM;
