
/* Targa reader/writer, revision 6
 * (c) 2001-2002, Emil Mikulic.
 *
 * This code is covered by the GNU GPL.
 */

#ifndef __included_targa_h
#define __included_targa_h

#include <stdio.h>

typedef unsigned char byte;
typedef unsigned short word;

#define TGA_REVISION 6

#ifdef __cplusplus
extern "C" {
#endif

typedef enum { TOP_TO_BOTTOM = 0, BOTTOM_TO_TOP = 1 } tga_line_order;
typedef enum { RGB = 0, BGR = 1 } tga_color_order;

typedef struct {
	byte *data;
	word width, height;
	byte bits_per_pixel;

	tga_line_order line_order;
	tga_color_order color_order;
} tga_image;

/* We use this to pass more verbose error messages. */
extern char *tga_error;



/* create a tga_image structure from reading a Targa file
 * returns NULL on failure
 * don't forget to deallocate [output]->data and [output] when done
 */
tga_image *tga_read(const char *filename);



/* write a tga_image structure into a Targa file
 * img : fully initialised tga_image structure
 *
 * returns zero or one on failure or success, respectively
 */
int tga_write(	const char *filename,
		const tga_image *img);



/* free a tga_image structure and its image data
 * remember to pass the tga_image as a pointer to a pointer to the struct
 */
void tga_free_img(tga_image **img);



/* convert tga_image structure to a different format
 * returns NULL on failure
 * don't forget to deallocate [output]->data and [output] when done
 */
tga_image *tga_convert(	const tga_image *img,
			const byte bits_per_pixel,
			const tga_line_order line_order,
			const tga_color_order color_order);



#ifdef __cplusplus
}
#endif

#endif