
/* tga2avi - slaps a set of numbered targas together into an AVI
 * (c) 2001-2002, Emil Mikulic.
 *
 * This code is covered by the GPL.
 * Win32 only because it uses Video for Windows
 */

#include "targa.h"

#define PROGRAM "tga2avi"
#define VERSION "v0.4 (2002/02/06)"
#define COPYRIGHT "Copyright (c) 2001-2002, Emil Mikulic"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <vfw.h> /* don't forget to link with vfw32.lib and user32.lib! */

#include <stdio.h>
#include <stdlib.h>



void error(char *file, int line, char *err)
{
	fprintf(stderr, "%s:%d: %s\n", file, line, err);
	exit(1);
}

#define ERR(x) error(__FILE__, __LINE__, x)
#define AVIERR(x) if ((x) != AVIERR_OK) ERR(#x)



int main(int argc, char **argv)
{
	char *outfn;
	int fps = 0;
	int img_width, img_height;
	int frame_num, avi_frame;
	char *pattern;
	int frame_begin, frame_end, frame_step;
	char fn[1024];
	tga_image *in, *tga;

	LPBITMAPINFOHEADER bih;
	PAVIFILE af = NULL;
	AVISTREAMINFO asi;
	PAVISTREAM as = NULL, ascomp = NULL;
	AVICOMPRESSOPTIONS opts;
	AVICOMPRESSOPTIONS FAR * aopts[1] = {&opts};
	HANDLE dib;
	int memsize;

	if (argc != 7)
	{
		if (argc != 1) printf("error: bad number of parameters\n\n");

		printf(PROGRAM " " VERSION "\n"
			"Using Targa code revision %d\n"
			COPYRIGHT "\n\n\
usage: tga2avi <outfile> <framerate> <pattern> <start> <end> <step>\n\n\
example:\n\
 >tga2avi out.avi 25 abcd%%04d.tga 1 100 1\n\
 Will convert abcd0001.tga through abcd0100.tga into out.avi\n\n\
 >tga2avi out.avi 25 img.%%d.tga 2 12 2\n\
 Will convert img.2.tga through img.12.tga (only evens) into out.avi\n\n",
	TGA_REVISION);
		return 0;
	}

	outfn = argv[1];
	fps = atoi(argv[2]);
	pattern = argv[3];
	if (fps == 0) ERR("Invalid frame-rate!");
	frame_begin = atoi(argv[4]);
	frame_end = atoi(argv[5]);
	frame_step = atoi(argv[6]);
	if (frame_end < frame_begin) ERR("Invalid end frame!");
	if (frame_step < 1) ERR("Invalid frame step!");
	
	/* check for existance and format of first frame */
	sprintf(fn, pattern, frame_begin);
	tga = tga_read(fn);
	if (!tga) ERR(tga_error);

	img_width = tga->width;
	img_height = tga->height;
	tga_free_img(&tga);



	/* allocate DIB */
	memsize = sizeof(BITMAPINFOHEADER) + (img_width*img_height*3);
	dib = GlobalAlloc(GHND,memsize);
	bih = (LPBITMAPINFOHEADER)GlobalLock(dib);

	bih->biSize = sizeof(BITMAPINFOHEADER);
	bih->biWidth = img_width;
	bih->biHeight = img_height; /* negative = top-down */
	bih->biPlanes = 1;
	bih->biBitCount = 24; /* B,G,R */
	bih->biCompression = BI_RGB;
	bih->biSizeImage = memsize - sizeof(BITMAPINFOHEADER);
	bih->biXPelsPerMeter = 0;
	bih->biYPelsPerMeter = 0;
	bih->biClrUsed = 0;
	bih->biClrImportant = 0;

	if (HIWORD(VideoForWindowsVersion()) < 0x010a)
		ERR("VFW is too old");

	AVIFileInit();
	AVIERR( AVIFileOpen(&af, outfn, OF_WRITE | OF_CREATE, NULL) );

	/* header */
	memset(&asi, 0, sizeof(asi));
	asi.fccType	= streamtypeVIDEO;// stream type
	asi.fccHandler	= 0;
	asi.dwScale	= 1;
	asi.dwRate	= fps;
	asi.dwSuggestedBufferSize  = bih->biSizeImage;
	SetRect(&asi.rcFrame, 0, 0, img_width, img_height);

	AVIERR( AVIFileCreateStream(af, &as, &asi) );

	memset(&opts, 0, sizeof(opts));

	if (!AVISaveOptions(NULL, 0, 1, &as,
		(LPAVICOMPRESSOPTIONS FAR *) &aopts))
	{
		ERR("Couldn't get AVI save options");
	}

	AVIERR( AVIMakeCompressedStream(&ascomp, as, &opts, NULL) );

	AVIERR( AVIStreamSetFormat(ascomp, 0,
			       bih,	    // stream format
			       bih->biSize) ); // format size

	avi_frame = 0;
	for (frame_num = frame_begin; frame_num <= frame_end;
		frame_num += frame_step)
	{
		sprintf(fn, pattern, frame_num);
		in = tga_read(fn);
		if (!in) ERR(tga_error);
		tga = tga_convert(in, 24, BOTTOM_TO_TOP, BGR);

		if (tga->width != img_width) ERR("TGA: Invalid width!");
		if (tga->height != img_height) ERR("TGA: Invalid height!");

		memcpy((LPBYTE)(bih) + sizeof(BITMAPINFOHEADER), 
			tga->data, bih->biSizeImage);

		AVIERR( AVIStreamWrite(ascomp,	// stream pointer
			avi_frame,		// time of this frame
			1,			// number of frames to write
			(LPBYTE)(bih) + sizeof(BITMAPINFOHEADER),
			bih->biSizeImage,	// size of this frame
			0,			// flags
			NULL,
			NULL) );
	
		tga_free_img(&tga);
		tga_free_img(&in);

		printf("%05d/%05d frames (%.2f%%)\r",
			frame_num-frame_begin+1, frame_end-frame_begin+1,
			(double)(frame_num-frame_begin)/
			(double)(frame_end-frame_begin)*100.0);
		fflush(stdout);
		avi_frame++;
	}
	printf("\n");

	if (ascomp) AVIStreamClose(ascomp);
	if (as) AVIStreamClose(as);
	if (af) AVIFileClose(af);
	GlobalUnlock(dib);
	AVIFileExit();

	return 0;
}
